import {createContext}from 'react';

const appContext = createContext({
    buyBasketList : [],
});

export default appContext;