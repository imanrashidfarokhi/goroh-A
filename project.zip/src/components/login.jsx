import { Component } from "react";
import axios from "axios";

class login extends Component{
    
    state ={
        IsLogin : true ,
        errMsg : "",
    }
    render(){

        return(
            <>
            <div className="text-center ">
              {this.make()}  
              <p>{this.state.errMsg}</p>
            </div>

            </>
        )
    }
    make = ()=> {
        if(this.state.IsLogin===true){
            return (
            <>
                <p><span>Email : </span> <input id="loginEmail" type="text" /></p>
                <p><span>Password : </span> <input id="loginPassword" type="Password" /></p>
                <p>
                    <button  className="btn btn-secondary mx-2" onClick={this.loginE}>Login</button>
                    <button  className="btn btn-secondary mx-2" onClick={this.chengToSingupE}>Sinup</button>
                </p>
            </>
            )
            
        }else {
            return (
            <>
                <p><span>image : </span> <input id="sinupimage" type="text" /></p>
                <p><span >User name : </span> <input id="sinupUsername" type="text" /></p>
                <p><span>Email : </span> <input type="Email" id="singupEmail" /></p>
                <p><span>Password : </span> <input id="sigupPassword" type="Password" /></p>
                <p><span>replas Pasword : </span> <input id="sigupPassword2" type="Password" /></p>
                <p>
                    <span>Type : </span>
                    <select name="type" id="singupType">
                        <option value="client">buyer</option>    
                        <option value="seller">seller</option>    
                    </select> 
                </p>
                <p>
                    <button className="btn btn-secondary mx-2" onClick={this.chengToLoginE}>Login</button>
                    <button  className="btn btn-secondary mx-2" onClick={this.singupE}>Sinup</button>
                </p>
            </>
            )
        }
    }
    chengToSingupE =()=>{
        this.setState({IsLogin : false ,errMsg:''});
    }
    chengToLoginE =()=>{
        this.setState({IsLogin : true,errMsg:''});
    }
    loginE = ()=>{
        axios.post("https://project000014.liara.run/api/auth/login",{
            email :  document.getElementById("loginEmail").value,
            password :  document.getElementById("loginPassword").value
        }).then((res)=>{
            this.props.setToken(res.data.data.token);
            this.props.homeE();
            console.log(res.data.data)
        }).catch((err)=>{
            this.setState({errMsg:"Error  massage : "+err})
            console.log(err)
        })
    }
    singupE=()=>{
        if(document.getElementById('sigupPassword').value===
            document.getElementById('sigupPassword2').value)
        axios.post("https://project000014.liara.run/api/auth/register",{
            name :  document.getElementById("sinupUsername").value,
            email :  document.getElementById("singupEmail").value,
            password :  document.getElementById("sigupPassword").value,
            usertype :document.getElementById('singupType').value,
            image : document.getElementById('sinupimage').value
        }).then((res)=>{
            this.props.setToken(res.data.token);
            document.getElementById("sinupUsername").value = ''
            document.getElementById("singupEmail").value = ''
            document.getElementById("sigupPassword").value = ''
            document.getElementById('sinupimage').value = ''
            document.getElementById('sigupPassword2').value = ''
        }).catch((err)=>{
            this.setState({errMsg:"Error  massage : "+err})
            console.log(err)
        })
        else
        this.setState({errMsg:"defrents Passwords"})
        this.chengToLoginE()
    }

}

export default login