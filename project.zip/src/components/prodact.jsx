import { Component } from "react";
import 'bootstrap/dist/css/bootstrap.css';

class pordact extends Component{
    state = {
        addToBuylistTxt :"add to buybasket",
        isBuyed : false,
        imagecount : 0,
        addToBuyBasketClass :"bg-success btn btn-sm btn-outline-success"
    }
     iamgeAdderss = this.props.items.imageAdderss ; 
     prodactName  = this.props.items.name ;
     about =  this.props.items.about ; 
     price = this.props.items.price;
     count = this.props.items.count;
    render(){

        return(
            <>
            <div className="col-4"> 

            {this.makeImage()}
            <br />

            <h3 className="fs-4">{this.prodactName}</h3><br />
            <span>About : {this.about}</span><br />
            <span>{this.CuontE()} </span><br />
            <button className={this.state.addToBuyBasketClass} onClick={this.addToBuylist}> {this.state.addToBuylistTxt} </button>
            </div>
            </>
        )
    }
    
    addToBuylist  = ()=>{
        const {count , isBuyed} = this.state;
        if(isBuyed){
            this.setState({count:count+1 , addToBuylistTxt : "add to buybasket" , isBuyed : false ,
               addToBuyBasketClass :"bg-success btn btn-sm btn-outline-success"});
            this.props.buyBasketdeleltE(this.props.items.ID)
        }
        else{
            this.setState({count:count-1 , addToBuylistTxt : "remove to buybasket", isBuyed : true ,
            addToBuyBasketClass :"bg-danger btn btn-sm btn-outline-danger"});
            this.props.addProdactTOBuybasket(this.props.items)
        }
        
        
    }

    makeImage = ()=>{
        const {imagecount} = this.state;

        return(
            <>
            <img className="img-thumbnail rounded mx-auto d-block " 
            src={this.iamgeAdderss[this.state.imagecount]} alt="iamge" 
            style={{width :'200px' , height :"200px" }}/>
            <div>

            <svg onClick={this.lastImageE} xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
            </svg>
            {this.iamgeAdderss.map((V,I)=>{
                if(I!==imagecount) return (<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-record" viewBox="0 0 16 16">
                <path d="M8 12a4 4 0 1 1 0-8 4 4 0 0 1 0 8m0 1A5 5 0 1 0 8 3a5 5 0 0 0 0 10"/>
                </svg>)
              else return (
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-record2-fill" viewBox="0 0 16 16">
                <path d="M10 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0"/>
                <path d="M8 13A5 5 0 1 0 8 3a5 5 0 0 0 0 10m0-2a3 3 0 1 1 0-6 3 3 0 0 1 0 6"/>
                </svg>
              )
            })}
            <svg onClick={this.nextImageE} xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-circle" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0M4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5z"/>
            </svg>
            </div>
            </>
        )
    }
    CuontE  = ()=>{
        if(this.count=== 0 )
            return ("not exist");
        else 
            return (<><span>price : {this.price}$</span> <br />  <span>  cuont : {this.count}</span> 
            </>) ; 
    }
    nextImageE = ()=>{
        var { imagecount} = this.state;
        imagecount+=1;
        if(this.iamgeAdderss.length === imagecount)
            imagecount = 0;
        this.setState({imagecount:imagecount})
    }
    lastImageE = ()=>{
        var { imagecount} = this.state;
        imagecount-=1;
        if(-1 === imagecount)
            imagecount = this.iamgeAdderss.length-1;
        this.setState({imagecount:imagecount})
    }

}

export default pordact