import { Component } from "react";
import 'bootstrap/dist/css/bootstrap.css';


class bar extends Component{

   state = {
        serchText : ""
   }
    render(){

        return(
            <nav className = "navbar navbar-dark bg-primary sticky-top text-graee  text-center fs-5 shadow-lg p-3 mb-5 rounded" >
                <div onClick={this.props.goToProfile} >
                {this.profileIcon()}    profile
                </div>
                <div onClick={this.buyBasketE2}>
                {this.buyBasketIcon()}  buy bsket
                </div>
                <div>
                {this.serchIcon()} 
                    <input  type="text" value={this.state.serchText}  onChange={(e) => this.setState({serchText:e.target.value})}/>
                </div>
                <dir>
                <span onClick={this.props.homeE} >  Home   </span> 
                </dir>
            </nav>
        )
    }
    
    buyBasketIcon = ()=>{
        if(!this.props.isBuyBasket){
        return(<>
        <svg  xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-minecart" viewBox="0 0 16 16">
        <path d="M4 15a1 1 0 1 1 0-2 1 1 0 0 1 0 2m0 1a2 2 0 1 0 0-4 2 2 0 0 0 0 4m8-1a1 1 0 1 1 0-2 1 1 0 0 1 0 2m0 1a2 2 0 1 0 0-4 2 2 0 0 0 0 4M.115 3.18A.5.5 0 0 1 .5 3h15a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 14 12H2a.5.5 0 0 1-.491-.408l-1.5-8a.5.5 0 0 1 .106-.411zm.987.82 1.313 7h11.17l1.313-7z"/>
        </svg>
        </>)}
        else {return(<>
        <svg  xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-cart-x" viewBox="0 0 16 16">
        <path d="M7.354 5.646a.5.5 0 1 0-.708.708L7.793 7.5 6.646 8.646a.5.5 0 1 0 .708.708L8.5 8.207l1.146 1.147a.5.5 0 0 0 .708-.708L9.207 7.5l1.147-1.146a.5.5 0 0 0-.708-.708L8.5 6.793z"/>
        <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
        </svg></>)}
    }
    buyBasketE2 = ()=>{
        if(this.props.isBuyBasket)
             this.props.homeE()
        else 
            return this.props.buyBasketE()
    }
    serchIcon = ()=>{
        return<svg onClick={()=>{this.props.serchE(this.state.serchText)}} xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
      </svg>
    }
    profileIcon = ()=>{
        return(<>
        <svg  xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
        </svg>
        </>)
    }
}

export default bar