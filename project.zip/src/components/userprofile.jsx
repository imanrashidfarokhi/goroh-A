import { Component } from "react";
import Asset from './asset';
import LodeProdact from './lodeProdact';
import EditProdact from './editProdact'
import axios from "axios";

class userprofile extends Component{

    state ={
        chengpasswordViwe : false,
        addProdactViw : false,
        editProdactViw : false,
        selectItem : {},
        errmsg : '',
        infomation :  this.props.infomation
    }

    render(){

        return (<>
        {this.make()}
        </>)
    }
    make =()=>{
        if(this.state.chengpasswordViwe)
            return(<>
                <div className="d-grid gap-2 col-6 mx-auto text-center ">
                {/* <p><span>last Password  : </span> <input id="chengPasswordLP" type="Password" /></p> */}
                <p><span>new Password : </span> <input id="chengPasswordNP" type="Password" /></p>
                <p><span>replas Pasword : </span> <input type="Password" id="chengPasswordNP2"/></p>
                <span>{this.state.errmsg}</span>
                <button className="btn btn-success" onClick={this.chengpasswordE} >cheng</button>
                <button className="btn btn-danger" onClick={this.cansel}>cansle</button>
                </div>
            </>)
        else if(this.state.addProdactViw){
            return(<>
                <LodeProdact addPE={this.addPE} token = {this.props.token }cansel={this.cansel} api={this.props.api}/>
            </>)
        }
        else if(this.state.editProdactViw){
            return(<>
                <EditProdact updatePE= {this.updatePE}items={this.state.selectItem} token={this.props.token} cansel={this.cansel}/>
            </>)
        }
        else
        return(
            <> <div className="d-grid gap-2 col-6 mx-auto text-center ">

                <img className="rounded-circle mx-auto d-block" src={this.state.infomation.image} alt="profileImage" /><br />
                <span>username :  {this.state.infomation.username}  </span><br />
                <span>emile : {this.state.infomation.email }  </span><br />
                <span>cash : {this.state.infomation.cash}  </span><br />
                <button className="btn btn-secondary">pay</button>
                <button className='btn btn-secondary' onClick={this.gochengpasswordE}>cheng password</button> <br />
                 </div>
                {this.makeAssets()}
                <button className="btn btn-danger" onClick={this.props.logoutE}>log out</button>
            </>
        )
    }
    makeAssets =()=>{
        if(this.state.infomation.type!='client')
        return(<> 
        <div className="row mx-auto text-center">
        <span className="fs-2 ">assetes :</span> <br />

         {
            this.state.infomation.assets.map((V)=>{
                return (<Asset items = {V} editAssetE = {this.editAssetE}/> )
            })
        }
        </div>
     <button className="btn btn-success" onClick={this.addProdactE}>Add new prodact</button></>)
    }
    gochengpasswordE = ()=>{
        this.setState({chengpasswordViwe : true , addProdactViw:false ,editProdactViw : false})
    }
    chengpasswordE = ()=>{
        if(document.getElementById("chengPasswordNP").value===
            document.getElementById("chengPasswordNP2").value)
        axios.put("https://project000014.liara.run/api/user/password",{
            password : document.getElementById("chengPasswordNP")

        }).then((res)=>{
            this.cansel()
        }).catch((err)=>{
            this.setState({errmsg:'Error masseag : '+err.massage})
        })
        else
        this.setState({errmsg:" defrant passwords"})
    }
    cansel = ()=>{
        this.setState({chengpasswordViwe : false , addProdactViw:false,editProdactViw : false, errmsg : ''})
    }
    editAssetE = (ID)=>{
        var selectItem = this.state.infomation.assets.find((V)=>{
            return V.ID===ID;
        })
        this.setState({selectItem: selectItem ,chengpasswordViwe : false , addProdactViw:false,editProdactViw : true ,  errmsg : ''})
    }
    addProdactE=()=>{
        this.setState({addProdactViw:true,chengpasswordViwe:false,editProdactViw : false , errmsg : ''})
        
    }
    addPE = ()=>{
        this.props.edeitprodacts()
        this.setState({infomation : this.props.infomation});
    }
    updatePE = ()=>{
        this.props.edeitprodacts()
        this.setState({infomation : this.props.infomation});
    }
}

export default userprofile