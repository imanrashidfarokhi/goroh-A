import { Component } from "react";


class item extends Component{
    
    state =  {
        count : this.props.count,
        
    }

    render(){

        return(
            <>
            <samp>{this.props.name}  </samp>
            <samp>pric : {this.props.price}  </samp>
            <samp>count : {this.state.count}  </samp>
            <button onClick={this.AddcountE}>+</button>
            <button onClick={this.removecountE}>-</button>
            <button onClick={()=>{this.props.deleltE(this.props.ID)}} >delete</button>
            </>
        )

    }
    
    AddcountE = ()=>{
        const {count} = this.state
        this.setState({count : count+1})
        this.props.chengcountE(this.props.ID,count+1)
    }
    removecountE = ()=>{
        if(this.state.count>0){
        const {count} = this.state
        this.setState({count : count-1})
        this.props.chengcountE(this.props.ID,count-1)
        }
    }

}

export default item