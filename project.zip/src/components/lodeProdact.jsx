import { Component } from "react";
import 'bootstrap/dist/css/bootstrap.css';
import axios from "axios";


class lodeProdact extends Component{

    state ={
        newimageAdderss : "https://static.thenounproject.com/png/3022246-200.png",
        imageList : [],
    }
    render(){

        return(
            <> 
            
                <img  className="img-thumbnail rounded mx-auto d-block" 
                src= {this.state.newimageAdderss} alt="image" /><br />

                <div className="text-start form-inline  gap-2 col-6 mx-auto ">
                    <div className="form-group">
                        
                <span>image address : </span>
                <input className="formGroupExampleInput" type="text" id="addersText" />
                <button onClick={this.chengimgE}>add</button>
                    </div> <div className="form-group">
                <ul>
                    <li>image address</li>
                    {this.makeimageList()}
                </ul>
                <span>prodact name : </span>
                <input type="text" id="nametext" />
                </div> <div className="form-group">
                <span>prodact price : </span>
                <input type="number" min="0.00" max="10000.00" step="0.01" id="price"/>
                </div> <div className="form-group">
                <span>about :       </span>
                <input type="text" id="abouttext" />
                </div> <div className="form-group">
                <span>prodact count : </span>
                <input type="number" min='0' max = '200' step='1' id="count"/>
                </div> 
                <button onClick={this.addProdactE} className="btn btn-success">Add prodact</button>
                <button onClick={this.props.cansel} className="btn btn-danger">cansel</button>
                </div>
            </>
        )
    }
    chengimgE = ()=>{
        var newImageList =this.state.imageList;
        var newAdders  = document.getElementById("addersText").value;
        newImageList.push(newAdders); 
        if(newAdders!='')
            this.setState({imageAdderss: newAdders ,imageList:newImageList})
            document.getElementById("addersText").value = ''
    }
    addProdactE = ()=>{
        var Adders  = this.state.imageList ;
        var name  = document.getElementById("nametext").value;;
        var about  = document.getElementById("abouttext").value;;
        var price  = document.getElementById("price").value;;
        var count  = document.getElementById('count').value;
        axios.post("https://project000014.liara.run/api/article/creat",
        {name:name,about:about,price:price,count:count,imgList:Adders},{
             headers: {
                'x-auth-token': this.props.token
            }
        }).then(()=>{
            this.props.addPE()
            this.props.cansel();
            })

    }
    makeimageList=()=>{
        return(<>
        {
        this.state.imageList.map((V)=>{
            return (<ul>{V}</ul>)
        })}
        </>)
    }

}

export default lodeProdact