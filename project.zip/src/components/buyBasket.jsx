import { Component } from "react";
import Item from "./buyBasketItem";
import AppContext from './../contexts/app';
import axios from "axios";


class buyBasket extends Component{
   static contextType = AppContext; 
    state =  {
        buyBasketList : this.props.buyBasketList 
        
    }

    render(){

        return(
            <>  
                Your buyBasket : <br />{this.state.buyBasketList.map((V)=>{
                        return(<>  <Item name= {V.name} price = {V.price} count = {V.count} ID = {V.ID}
                         chengcountE = {this.chengcountE} deleltE = {this.deleltE}> </Item><br /></>)
                        })
                }
                <span>Summation = {this.summation()} </span>
                <button onClick={this.buyE}>Buy</button>
            </>
        )
    }
    
    chengcountE = (ID ,count)=>{
        var newProdactList = [];
        this.state.buyBasketList.forEach((V)=>{
            if(V.ID === ID)
                newProdactList.push( {ID:ID , name : V.name , price : V.price ,count:count })
            else newProdactList.push(V)
        })
        this.setState({buyBasketList: newProdactList})
        this.props.buyBasketchengcountE(ID,count);
    }
    deleltE = (ID)=>{
        var newProdactList = this.state.buyBasketList.filter((V)=>{
            return V.ID!=ID
        })
        this.setState({buyBasketList:newProdactList})
        this.props.buyBasketdeleltE(ID)
    }
    summation(){
        var res = 0;
        this.state.buyBasketList.map((V)=>{
            res+=V.price * V.count;
        })
        return res;
    }
    buyE=()=>{
            axios.put('https://project000014.liara.run/api/user/withdrawal',{
                amount :this.summation()
            },
            {
                headers:{ 'x-auth-token': this.props.token}
            }).then((res)=>{
                this.setState({buyBasketList:[]});
                this.props.buyE();
            }
            ).catch((err)=>{
                console.error(err)
            })
        }
}

export default buyBasket