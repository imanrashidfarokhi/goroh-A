import { Component } from "react";
import Pordact from  './prodact';


class pordacts extends Component{

    state = {
        prodactItems :this.props.Prodactlist
    }
    render(){

        return(
            <>
            <div className="  row mx-auto text-center ">
                
            {this.state.prodactItems.map((v)=>{
                return(<Pordact items = {v} addProdactTOBuybasket = {this.props.addProdactTOBuybasket}
                    buyBasketdeleltE={this.props.buyBasketdeleltE} ></Pordact>)
                })}

            </div>
            </>
        )
    }
    
    

}

export default pordacts