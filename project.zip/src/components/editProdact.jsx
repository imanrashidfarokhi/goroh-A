import { Component } from "react";
import axios from "axios";

class editProdact extends Component{

    state ={
        prodactName  : this.props.items.name ,
        about :  this.props.items.about ,
        price : this.props.items.price,
        count : this.props.items.count,
        newimageAdderss : this.props.items.imageAdderss[1],
        imageList : this.props.items.imageAdderss
    }
    render(){

            return(
                <> 
                
                    <img  className="img-thumbnail rounded mx-auto d-block" 
                    src= {this.state.newimageAdderss} alt="image" /><br />
    
                    <div className="text-start form-inline  gap-2 col-6 mx-auto ">
                        <div className="form-group">
                            
                    <span>image address : </span>
                    <input className="formGroupExampleInput" type="text" id="addersText" />
                    <button onClick={this.chengimgE}>add</button>
                        </div> <div className="form-group">
                    <ul>
                        <li>Image address</li>
                        {this.makeimageList()}
                    </ul>
                    <span>prodact name : </span>
                    <input type="text" id="nametext" defaultValue={this.state.prodactName}/>
                    </div> <div className="form-group">
                    <span>prodact price : </span>
                    <input type="number" min="0.00" max="10000.00" step="0.01" id="price" defaultValue={this.state.price}/>
                    </div> <div className="form-group">
                    <span>about :       </span>
                    <input type="text" id="abouttext" defaultValue={this.state.about}/>
                    </div> <div className="form-group">
                    <span>prodact count : </span>
                    <input type="number" min='0' max = '200' step='1' id="count" defaultValue={this.state.count}/>
                    </div> 
                    <button onClick={this.addProdactE} className="btn btn-success">update prodact</button>
                    <button onClick={this.props.cansel} className="btn btn-danger">cansel</button>
                    </div>
                </>
            )
        }
        chengimgE = ()=>{
            var newImageList =this.state.imageList;
            var newAdders  = document.getElementById("addersText").value;
            newImageList.push(newAdders); 
            if(newAdders!='')
                this.setState({imageAdderss: newAdders ,imageList:newImageList})
        }
        addProdactE = ()=>{
            var Adders  = document.getElementById("addersText").value;;
            var name  = document.getElementById("nametext").value;;
            var about  = document.getElementById("abouttext").value;;
            var price  = document.getElementById("price").value;;
            var count  = document.getElementById('count').value;
            axios.post("https://project000014.liara.run/api/article/put/:"+this.props.items.ID,
            {name:name,about:about,price:price,count:count,imgList:Adders},{
                 headers: {
                    'x-auth-token': this.props.token
                }
            }).then(()=>{
                this.props.updatePE()
                this.props.cansel();
                })
    
        }
        makeimageList=()=>{
            return(<>
            {
            this.state.imageList.map((V)=>{
                return (<ul>{V}</ul>)
            })}
            </>)
        }
    
    }

export default editProdact