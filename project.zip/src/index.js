import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './app';
import api from './api';

const root = ReactDOM.createRoot(document.getElementById('root'));

// api();

root.render(
  <React.StrictMode>
    <App/>
  </React.StrictMode> 
);

