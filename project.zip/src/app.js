import { Component } from "react";
import Prodacts from './components/prodacts';
import Loging from './components/login';
import BuyBasket from './components/buyBasket';
import Home from './components/home';
import Navbar from './components/navbar';
import buyBasket from "./components/buyBasket";
import UserProfile from './components/userprofile'
import 'bootstrap/dist/css/bootstrap.css';
import axios from "axios";
import pordacts from "./components/prodacts";
const api = axios.create({
    url : "https://project000014.liara.run" , 
    timeout: 1000,
})

class app extends Component{
    
    // ------------------navbar-----------------------------------
    buyBasketE = ()=>{
        this.setState({ isBuyBasket :true , pak:<BuyBasket
            buyBasketList = {this.state.buyBasketList}
            buyBasketchengcountE = {this.buyBasketchengcountE}
            buyBasketdeleltE = {this.buyBasketdeleltE}
            token = {this.state.userToken}
            buyE = {this.edeitprodacts}
            />})
    }
    homeE = ()=>{
        this.setState({pak:<Home userToken = {this.state.userToken} 
            addProdactTOBuybasket = {this.addProdactTOBuybasket}
            buyBasketdeleltE = {this.buyBasketdeleltE}
            serchE = {this.serchE}
            />, isBuyBasket :false})
    }
    serchE = (text)=>{
        axios.get("https://project000014.liara.run/api/article/" , {
            headers: {
                'x-auth-token': this.state.userToken
            }}).then((res)=>{
                var assets = res.data.data.map((v)=>{
                    return {
                            ID:v._id,
                            name : v.name ,
                            about : v.about ,
                            price : v.price,
                            count : v.count,
                            imageAdderss : v.imgList
                    }
                })
                console.log(assets)
                this.setState({pak:<Prodacts addProdactTOBuybasket = {this.addProdactTOBuybasket} 
                    
                    buyBasketdeleltE={this.buyBasketdeleltE} Prodactlist = {assets}/>})

            }).catch((err)=>{
                console.error(err)
            })
    }
    goToProfile = ()=>{
        this.setState({pak: <UserProfile api={this.api}  token = {this.state.userToken}
             logoutE={this.logoutE}infomation = {this.state.userinfomation}
             edeitprodacts = {this.edeitprodacts} />})
    }
    // ------------------------buybasket-------------------------
    buyBasketchengcountE = (ID ,count)=>{
        var newProdactList = [];
        this.state.buyBasketList.forEach((V)=>{
            if(V.ID === ID)
                newProdactList.push( {ID:ID , name : V.name , price : V.price ,count:count })
            else newProdactList.push(V)
        })
        this.setState({buyBasketList: newProdactList})
    }
    buyBasketdeleltE = (ID)=>{
        var newProdactList = this.state.buyBasketList.filter((V)=>{
            return V.ID!=ID
        })
        this.setState({buyBasketList:newProdactList})
    }
    addProdactTOBuybasket = (Prodact)=>{
        var buyBasketList = this.state.buyBasketList;
        buyBasketList.push({
            ID : Prodact.ID
            ,name : Prodact.name ,
            price : Prodact.price , 
            count : 1
        })
    }
    // /----------------------------login-----------------------------
    setToken = (token)=>{
        axios.get("https://project000014.liara.run/api/user/" , {
            headers: {
                'x-auth-token': token
            }}).then((res)=>{
                var user = res.data.data
                var assets = user.assets.map((v)=>{
                    return {
                            ID:v._id,
                            name : v.name ,
                            about : v.about ,
                            price : v.price,
                            count : v.count,
                            imageAdderss : v.imgList
                    }
                })
                user.assets = assets;
                this.setState({userinfomation:user , userToken:token})
                
                console.log(res.data.data)

            }).catch((err)=>{
                console.error(err)
            })
        
    }
    goLoigin =()=>{
        this.setState({pak: <Loging homeE={this.homeE}setToken={this.setToken} api={api} />})
    }
    // --------------------------------userprofile-----------------------------------
    logoutE =()=>{
        this.setState({userToken:'' , userinfomation:{}});
        this.goLoigin();
    }
    edeitprodacts=()=>{
        axios.get("https://project000014.liara.run/api/user/" , {
            headers: {
                'x-auth-token': this.state.userToken
            }}).then((res)=>{
                var user = res.data.data
                var assets = user.assets.map((v)=>{
                    return {
                            ID:v._id,
                            name : v.name ,
                            about : v.about ,
                            price : v.price,
                            count : v.count,
                            imageAdderss : v.imgList
                    }
                })
                if(assets.iamgeAdderss===undefined)
                    assets.iamgeAdderss = ["data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABIFBMVEX///+QZzXLrIeEXCzZrnl8VCZuSRxROBzisHCleURwTSOdcj60hU9eQiJvSx9/Vyh1UCSJYTCWbDnYrnrQrYJjOADUrX59Ux9WPB7NrIXcr3aMZDLSrYDm3tVzRQBsRQ57Tw9nPwBlRiLQs49gMwDquHiNYiy6ilOGWRujd0JzTRtpQgxFJwBqSSN5Vi60o5P27+aLZjlHLxWohFTl07/GlFthPRC/oHuzkGekj3qUe2LUysGonpTFvrd9XTtAIACCcmJMMRA9GQC5qZmIbE6ekIJ6ZE/q5N7Ft6lZOhRRMACqk3y7p5KXdVDKuKWmhmP78OPmxJm8ooedbjHdxqrv4tPSpGpwUy8zHgbWvaDk08CCUwulgFbGnWusiF23lnBW0iq3AAAMiUlEQVR4nO3d+1caSRYHcJuWVqDDSxEBUQkCQaLhoURl4q6b7PjIaN5MktH4//8XW/3uqq6uR3d11D31PSc/zRnk4617Ly2tLCzIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyDxEhrPjP96cP/SzSCyzV6eVyuDly3+9XP/3H2+aD/10BKf56nSnMtBAloycAed/nhnO4UM/MxFpvn3XqrQ0O0tezsx6/vnfi6fsbL49AbqB5mUJzZkBvQTO2ZNr0POLk63WYJDXoASEZtbPLq+uri7/PH47eyL1PL84rm5uacVsNq/lGYTA+MzI5fTqanoKnI+6nsPZ+8LmdjWdTmezQWIYcMkUPnsO/uW1QatSOT15nM7Z+5GlM4MhhtbQIz7PGjGdrdOTV49ogc7+MnSFtC/FADFM6JxTg7iXdWM4W5X9k1ezh16gzb+ut7erKkgaIgaqGA70ndMsEtPZAs6Lh3EC3T+WTqUTCTVEzynGCQ5u0XD+xoHbvPnQfeHp6MRw4dI69pwGYjp3ax9/g+7c0HW7iqKU1BIrkSQknFPYWJzUF+cHyeqGN/e2zgyRCI0bgpCRuFe4qy+CzD8lp5t9Lvt0ZhqsVSQJWc6pplo+M0m04/Dn59yLF7COTvRVkSykFXE6mnc8oPiT+vPzLVbHU0WikEzMXxo+H1DsSW3e3H75EqbjqCJZ6D+n6MrYy9U7y4sQcHFxZUPITG3eHH358iUHopTjEmlC+6UNWsT85S3wBYG11Oq3uLzhhm7pzJTjEilC/Dndez5ZNlJHgaupVKr2Nabwk/mod4c60AmoIk2IOad7WcuHBwJiO9ZM/Tg3Hwv8q9fnd70MADYaMYh0oVNEe2Xs7fc6NnARAW6k7NTinFTkUQ0nKGej1MA7qUSqED6nl/t3tg80IRIXmEqtRj+pB+g3zi7n4hyUs1QKMilE+in1E898vsCU8QGNkxpVOEeB/moa5ewriJNMLDII7UvF9TOw/pZDgWspOBFn6qdwoFVKMMLr855ulrPBQGQ4pVYRER9uTyCpRXmB89E8kxSj8fU7nflhL6OoZjkRYsFPZKzh0tJo2e8LjtEAMNpJXa2trlGNK3X7WXQ6y8YUUtH4iUw1HI8nsC9sTwSMvGvjwHgcHqPjBOUsgGCI2THdtz6BeZg9gQfyn1T7cVY36Gd1EXlOdjnTadPpEYtjCnH8LOALNOHKRggQEH/wAL96c4rFWA88sWWznGVomJKF4+d3QR91jMJhP6lDfzPXNtYiGe0ppPfV3V1bGE4c/43zcQJTtZ+swjb8P66uUoyLoUb32JbT2vcw4vj7KdYXBGLGaKST+i24cGh1JBvNci7fTUbPxt8DyvEYXn/hQNyeiHZScQ/EsDwWV4hGk9mZ392ervuqOR5f1/E+1j2BZJVhpn7Ff6u4FiSlnPPJ9d9LhnN8uxziY98T8LP8Si/iMPwsMBjJZxV23k0mnTBfALgYvic8HotvYeEH6TGiLEhCMnqokHg9EeJjW/rBMYMa4w4dL4e6ss8IpOwJ4Euxrgr6vIo/WO3oh3qmOD0UsAjBS2/mK6gDlolci7cgnewDYUab5oJEluuJaL6FIdPAEjJYO6OcIVQ0LYvuQy5grfaD57qCOGbgxDUeXvUMYSavadMM+YqQ9G1nG59uaGNGoLGT1Q5NYW4KiP6BE/6DtSCP07ewwONjNIYsj85kOrKEmYLxxtS05/1gjXVP1FLcP71gGjOIMeKVx3yq5axTCoaNSRx1+IDs68EL4dUMyRhlsHZUbao7QsV+G9wcOIzXEzzj0wvHmIG/Gv+C7E21fK/Xy1gpWkJj4LBdT9R+RPoBYrQSWl+RoY7Q0AHTRe3pjjBnF3G6P2cBco8XJ23Mg/EYOX40Z5Byuq7bwozq3JEynUBE3J5o30d9q+Jn9BJaYTfOjQWh+4QZ97ai6chHxADb9+V/ot47FBeYYrryMIwds+96fqGieXHvRwguwva90lVeRBRGHTOIcY26PFbqE1BCrQQJnWFjlvHaJiLAdvtIMd4+iCiMMWbg1Oh1NIBmGzrCfi6X8xVRy5oPAV9PtFO/utbbIxGF4AWQICLtRUB9ZBbKAPY8YF/1E6cTZIy2U7dd522uqKf028EPYUriYL0zS5jvuTW0bhPoaxBxf803ZdqvPV90oZHht4N2TQgz3Fi3bgFTHWHfuRNC0WDjkbO9DJ//ndg4Qov586sQJt5Yn1gAsw11p4Bm0jBRuzWfA1gPyL08sYVmzkWcWaxxqrltCIT9nO9uFj8v3Sg3lNdgfKI+UUIjw2/3YELHM6KDtb5vAaw21DM+X1nxho1q3djSnTSC92KVtgXeLVytqtcfXsdSIoP111TztaHuNaFBKlstWiy5N+5gbvpQVaFC403OanV0G6eY0JWHDbTb0BGW7futGuC/FBq0G5OEC823Oavq6ENkpmu0VqHXhrbQvdmqXFBJPPt23SSEdqrK7VG0M2svjzunhHYb6v4C0mPfByFUWICEJVVpdEvlSGfWMK7sOZNkpLtCZp+i2jd6CBWmkXsrSua3stFtgGJyM1cnTgmdNtT73AUUXsM0UkR3uHW7XeX2nuvMrrlApw31HHMBfTfMi61hIXBO/d/WRreb+8V6ZledMQP2Qc8RchdQvDBNIppf3Cgmy5k9ckuoKTqfEP6NB7HCNHJOMUSbSRtANTXvEKcZR8h0SEEBoXvJBAtRYsmaNnhlN3cUxmz/Mq6TlILJ7PHUEPmVFfHCIDH8PmHjZRYopnFmA8S+eS0IXoqWRw2dvYYlpIBJCPmI4IVJQymXwQCC5mw744vOLgz6khCSByqGqJTN1yq5iXdm7/tYIkUYOKBGCpsJCKkDFSU6lwz9XH9inlkIyCrEFVBNJyEMDNTQaeMIXWIm0+/3cxk0LEJ8AcFzSULI3YousR/AQUSCUMUB08bNnIkIg0Si0GlFKjFUGFrAdHLCSNPGPKcEYpgwpAOtu3GTETK+tvETc2QiQUgqYHJC9tc2jpCFiBWGd2CywkSmDUZIKWCSwoiLn9iKQSGtgIKFu7BQ9LQJChvUAooWZhEi/KVL5FZU6K2ICLEnFC6gcGGRRIzfipCQqYDChQkT/UKGDrTSEiksZuFzKnraeELWAqaL2YrYU5pFWzHqZQZZyNaBJjArtIZZDBERxln8zqThKGC2WBQvTLAVLSFzBxbN5yNUqLEQaeeUcJlhFzAIxBXQ+AMU4NmI7UMgFNCK4dOGswOL5p84ESvEE1VOYmgr8hcwr+VFCrc0g1gUNm0C51ThLqCWF1rDLfB4+SSnjRL0UQqY1wQLXSL8FUUt/kawgCE7wimgJlwIHjTBaYMK6QVMRMg0bSitGDJtECFDARMQJtqKkLCAGzFoAZMQiiLiFn8DBjIUMBFhSCuKmDYlog9XwKSEYqZNsBVdIVsHJiZkmzZRFn+JrwOTEybWiiW+DkxQyErkbcUSXwcmKRS1+JFWLHEXMEmhiMWPXvGXsC+zSQVMTmgR6eeUb9qUuAsIspOQMJFpo/J1oFXCE3FAWIhvxXiXGQEhtYCtwUwgEBWKmDZwK6JC6/EJBdw5FulDhYzThqcVYSG9gPui/+Q1ImRtRRrRa0VISOvAwc4rwb6gUPS08QuLNjC0gJV3CfwN+oAw5IcaURd/3xPSOnDQuhDvW1ioDNAvJOQyw21FV0jfgSfJ/C32ixPfh6iQiZGmjSOkdWBrV+iKgNM0P+YnqVZUmTpQ9IoIZna8v+N9YozIywzV34EhQPErApvzi+Mt53NxBF5mqP4CYoFJrIjQNC9OKkZbCrzMKGQpIyaRFUHMzG5LQZcZBfKISWhF0JXHRVBKEdOmXyAWcEfkVQRnzi9OdltbWtzLjFyaUMCWluCKYIrxkWOtXbiIfESlnCYUMPEVwRTQlr5PQOJe/OV02Aj9TSuCKd6nWEVoxTS+gIOdtw/NQgLacntzC/sbNuRjiv6CupXfvyKY0nx7vblZ5bzMwAkfakUwxfroLg4iRviQK4IpoC3V7WrVJyRNm4Dw4VcEU85vPmy7pSROG1T4SFYEU7xPYyOdU1jY2n+UEyY8w9nnkvGpbASi7y8LPcIVwZThxfsuQDLU8JGuCKaAtgz7rCi3hoPKm4d+mjED2hKndISPfkUwBbSlgn5mW/EprQimeJ8q6BM+pRXBlOaN9xFuQFh5RFcRAjOzP4Yv/0RXBFPMtqy8eyKf4xw15/8/E0ZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkbm8ed/nBCBkPU+CPEAAAAASUVORK5CYII="]
                user.assets = assets;
                this.setState({userinfomation:user })
                
                console.log(res.data.data)

            }).catch((err)=>{
                console.error(err)
            })
    }




    //-------------------------------------------------start----------------------------------
    constructor (props){
        super(props)
        
    }



    state ={ 
     pak : <Loging homeE={this.homeE} setToken = {this.setToken} api={api}> </Loging>,
     isBuyBasket : false,
     buyBasketList : [
        // {ID : 1 ,name : "N2" , price : 500 , count : 2},
        // {ID : 2 ,name : "N3" , price : 200 , count : 4},
        // {ID : 3 ,name : "N1" , price : 100 , count : 5},
        // {ID : 4 ,name : "N4" , price : 300 , count : 1},
],
    userToken : "",
    userinfomation : {},
    // userinfomation: {
    //     imgae : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqafzhnwwYzuOTjTlaYMeQ7hxQLy_Wq8dnQg&s',
    //     username : 'ali1234',
    //     email : 'ali@gmail.com',
    //     cash :45.22,
    //     type : 'seller',
    //     assets : [ {
    //         ID:1,
    //         name : 'laptap' ,
    //         about : 'Ram = 32GB  , Hard = 1TB' ,
    //         price : 340,
    //         count : 5,
    //         imageAdderss : ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQk0zNufBvC7jrwj0pDs0ZdG421adXS-BcRHg&s",
    //                         "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQDw8PDw8PDxUQDw8QDxAQEA8PFQ8VFREWFhUSFRUYHSggGBolGxYVIjEhJSotLi4uGB8zODUtNygtLysBCgoKDg0OGhAQGi0lHR0rLS8tLSsrLS0tLS8rKzctLy0tLS0wLS0tKy0uLystLS0tMC0tLS0vKy4tNy0tKy0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAQIDBAUGBwj/xABDEAABAwIDAwkEBwcCBwAAAAABAAIDBBESITEFQVEGEyIyYXGBkaEHQlKxIzNTYnKywQgUc4KSwtFD8BU1Y2TD4fH/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAQIDBAUG/8QAKxEBAAMAAQMCBQIHAAAAAAAAAAECERIDITEEQQVRcYHwYZETFCIjMrHR/9oADAMBAAIRAxEAPwD1oBVIEUgpREBERAUopUApUKbIJClFKAi8P5c+0HaR2jVU9DUR00VI4x5thJlc2weSZAbnFcBo3DvWFH7RdvxXDn0k1m4yTHE8Yb2xXjIFlrHRvaNiB78i8Qh9ru1o7ifZ1O/DbFhE0Nr6Xu51lnU/twcDabZUje2OfF6Fg+aielePNZ/YexBF5fB7cNnkgS01bF24Inj84PotrTe17Yr7XqJY/wAdPN82grPB3ikLmab2g7Ik6u0qUfjfzX5wFt6TblHKAYqulkvpgniffyKDYIoaQdCD3ZqqyAiIgIiICIiAiIgIiICKUQQilEGCpRFIIpRBClFKCFKKQFABVIApQECK3Uy4GPefcY5x/laT+iD5P2xPjra2Uf6lZUv78Urj+qpjkWBASRcm5JJJ4krIjK9j0/akLVlnsncLgOIva9ja9tLrIi2hJm10ji17jjBN73sC7PfkM+xYDSql08p8unpxSe1obmePEbk6C2TWN88IFz26rGdSMOrWnvaFkQyYmNPZY94yUFelEUtHjs4LRMTjBk2bGfcb4XHyWom2VKCbMaRc2sRpu1XREqglc/X9D0Or7Z9MhHKYaGAVUX1Zmj/hvc38pXRUu2NpxfV7UrG9hllcPJziFbBVV1jT4X0K7uz+fphyltIOXW3oz0doCQcJI4XX82X9VtYvant5jWudDSTNJIDjC4BxFrgFrxnmuVuFN+0jxVb/AAvoT42PumLT7u3h9tla0fS7Lif/AA5ZGX9HLZU/t1gt9Ns6pj44JGP/ADBq80knd1cRsG4LEk2bixYRwGLO3FVyV8jnOc8tcXOa512M6RbpuyHEDXesLfCqe1jnL1uk9tuyX9cVcP44Wu/I4rb0ntU2LJkK5rP4kU8fqW2XhD6lmQdBC+wcDdrhiu7FiJDhmNB2DerTjSE50uH8EhBGfEgrC3wy0eLfn7nN9RbK2tTVbDJSzxVDQbF0T2vDTwNtD2FZq+evYrOWbbdHAXNikp5cbC7FcNILcWlyL623nivoZebenC01n2XidQilFRIiIgIiIMOyWVVkspEIqrJZBFksqrIggBSpSygEU2U2QRZablrUGLZm0JBkW0VTbvMTgPUhbqy5D2u1HN7DryNXMijH887Gn0JSB8zw5NHcritNUgr2enOViBlxvV8LBaVkQPzsVtEtK2ZlPKWG+49YLY6i4zvvWrBWTQvs8N3Oy8dy6Ol1OM57L3pz7+6+4KkhZTo1ZcxdmueaLSpLlcLVbAVZsrwS1S59ksrTyo5GKSVQ56kq2VXVZ7KSqSqiqSqyo772BU+LalXL9nTYe7E4D+1e+rxj9nSm/wCZT/E+KPyxO/Ve0L5bqTt5n5y3jwhFKKiUKURARFKDFsilFIIpRBClFKgQpRSgJZSApQRZede3qpwbHwfbVcEfkHSf2L0deSftE1FqWgi+Opkk/oit/wCRTHkeFgqsK2VLXL1Kyqugq4xyshwVQW0SszWSK8yTeNRmsFrlW161iWtbY61hD2tcPeF+7sVp8atbCmxMczh0h3HX1+azZWrvrbY1pNdhr5QrVlkyhWbKsz3ZzXFt+is2V15uqCEZTCy9Wyrj1Q5QylQVbkNgT2KsqxVO6Lu4qnUtlZlR7l+z3S4dmTSfa1Tz4Na1v+V6iuI9jFLzexKT/qc7L/VISPRduvlnQIiICIiAiIgx0RFIIikKARFKApAQKUBSgRAXh37Rc959nR/DDUP/AK3sH9i9xXzv7f58W1423+rooW24EySuPzCtXyPNkUKLrsi+eVVakOVN0uton5IXmScVdBWIr0Lty1pf2lest1sSfDI3tNj45f4XRzBcdTOsV2JkD42PHvNBPfv9brs6d8jHb0f6oxgyrGeVkSlWCFpyL0WrKlyrKocrRLmtC05WnKtxVp5SZYWhQ4rFrXdArIcVi1DC8sYNXva0eJt+q5fVWzpW+ikeX1ZyEpeZ2Xs+Le2lhv3loJ+a3qs0UWCKJg9yNjfJoCvL56WwiIgIiICIiDHRUh4OhCqQFIUKUBSoUPjB1QVhSsN8T29VxKtireNfUINiEWE2u4t8ldbVt7QgyF8xe2aox7crODOYjHhBGT6kr6abM06OC+T/AGg1fO7W2k7/ALydo7mOwD8qtXyNAoKXS625ahCqBVKK1b8RUpabFUgpddEW91Wwhdot/suqIbgOmo/ULloJLHPT5LdUr9CF2dOYtDr9P1MtrbyG6svar7HAi6hwXTj0epWto2GIVaesmQLHkU64b0Y71aeFW9Y8sirMuS/ZRIVkcm6Yy7RoIviq4L9wkBPoCsBzl0/spp+d25QDUMe+Q9zY3H52XF6y39tlXy+pFCIvGaiIiAiIgIiIMQxNO4KnmRuLh3FXrJZBZLXjRwPeP1CB7hq3yKvWSyChso4EevyVQeDoQpLOxQY/9mx+aCsKiWBrtR4hQIraehIU9Ibz4gH5IMKalc3MZhWLrah54X7j+hWFV1UV7EOxb7CxHnqmiy0r5M2vPzlTUSfaTzPz+88n9V9T1dcyMF18gLkuIYB3k6LwmfYTC5zIamCaxIDQ5hPkCT6KOUQnJcIoXVVnJuRusAN75s/xkVqKjZgb1myR/iBHzCty1GNZddXsrkW6poH1jKiMOaYxzDm2vjm5tvTvlfI6b1z7qA7nA94WTS1lXC0sile1pdG8ta/ImN4ewkHLJwv3rSl65O/ZW0TMxk/VtZ+QdaJY4YeZqnSNlc0QPOkeDETzgaf9RluN1qpeT1a3nL0lQRC8xyubE97Y3gA4S5oIBsQdd4W1pOW9dDOyezMTI5GfUtaDzjmue44bC5LG9wGi3NF7TiKKtpZKbG+qNQ8TtktgfKLNcWFp6uRBB90d6fxLReYr/j7arTluX8fo8/8A/qztn1eEhrtDoeH/AKXcUHKyhnqKNtXjdCyfHI2WLnQwNp5GMbZuK4xuZkB7vYto+i2JV104hFIYy2lawY30oBtI6V7Ggsv7gOWWG2V1vHqLdOeWdohpWcnXJQyq6ZFkSbHgbRGpiklcccwa0Fr2hjX9C5AyOFzb3OXAK9S8m5ZNmzbSbKMMMpjMRbm5oLAXh99xfpbcc9y9Svqaz/r7u6nW2sT8/wDuNa9yxnlZVdQyQxxSvdG5srQ5uBxJbfc4ECxyPEZarXSTK8dSLRsIteJhTM+y18j81dnkWI9ypa+OHqzqouXoXsDp8e2HPtlFSSm/AlzGj5leb4l7D+zlTXn2hLbqxQMB/E55PyC8/wBXfaxClIe5oiLz2giIgIiICIiCxdTdUogrupVtSguIqLqHSAC5IAGpOSC4oc4AXJAA1JyWrqtsAZRjEfiOQ8tSuT5QcpXREhzJZCADicyRkQvwfhwk8Rl3qupx1tZtdjQcNjYZvd0Wt7c1xW1+V0bSQwmV2uKzwzP7wGfp3rkK/as9T9YcYbZ1mFzGg7sLQNbHW/HNYRm3F0jbZ2JbIeH3ipzfJvyZG09qyzAmSZj7ZtwvcwNNjbCxt8/G64naVKScbmEgkm5JAfbM5k3J3WHYuokkJcW3DssJY5wYDnc3tuyGRF1ptox5kMY3pAYgwlzm53JZmNLa9tipGogqZo+jHLNFa4MbHPu34iGggAWsbnhqsyHlJVNAxSRvByBkY2xOV7vADnkaEN4jNYUkYDcLgS3Lm+rhiL3HOVwB1Ad0bk65KwGm5c42cQ4MIDi6ou63Rve3YQ0eajDW8btuJ+U1FG99hbm+gXXzF74sPmT2BQJtnPF7VEPFwwvaDfqg3JdqDk1aRgJDhYAR43SMdcNZcgAtF8TiDudfyuojkJOJuI2ucQ67QOrieeixu7o+N8kw1v8A/hNO8XiroshdwlHNlovYYsWHDnbUbxxVM3JWoIxNZHMNQWOBBHG5AHqtHcZdWwcRez+aJaBoOs5x33tuVcZLX2aXh/RFm2ElrAmzh0Y278rkW4XTJOy7UbDkb1qeQdrWucPNtwsB1KBcBxG4g/IhbqDlBVsbdtQXNHQxyXlZG452BcCXuGt8xbdos48qZDZs8FPMMPvRdN+fWIDg1g7xfMHNImYOzmA2Vowh9xe+HMC+Wdt+gW1g5UVzKR9DivTvIc6INj1xh9w62LrNG9bIV+zpBaWkMJF7uhkBbllZtsOI3vpcDig2fs6TDzdXNC5/UjljcTpe9mt07cW5aV614/NT3+bR1e2jI1rXtLcOQyPrn2epWI6rB0K6ZvJR8gJpqmmqACAcDxlfQENLrHXVYNXyXqmHpUxPa3C6/gDf0W1fWWiM7E7jQPlJ3q1dZ8+zizrxyR/ia5n5gsf924O/VT/Mb5Z4sr339nSntQ1ktuvVBgPEMib+rivB/wB2d2HuNl9J+wul5vYsTiLGSaoefCQs/tWXUvFvCYh6AoUqFkkREQEREBERBjqURAUOcALkgAakmyiR4aC5xsBqudq5xI8/TN1OFjjhIG6wUTOJiGxqtrtGUYxH4jkPLUrVzVD3m7nE/IdwVLqd490+GfyVtUmdXiITdLoiqljVOz4JTeSGJ5+JzGlw7nahayo5L0zrlofEXa824EXta+F4cB4BbslUuKnUY5Gr5Ia4Jg4EWwytN+7E02Ge7Cuc2pyVqR0mwslJdd2CU4j3k4Lg9mfavTHBWHtTlJxh4ftPZ1RG674ZYw29sUJMYytlcFp79VrHyg5AXblcF13OsDbp2yAJOQsON9V749i1tbsenm+tp4ZO10bSfO11P8Q4PFC9vQaXdUtIe1lhHbPosyxu3FzuHiqiTbrBjpAMV3AmUONzjdcCJhFsr38Dl6bV8g6F98LJISd8cjjbwfcLSVfs3+xqfCWP+5p/RWi8K8ZcbALB8jA29nMIzwsOgbG4kl787ix8wpgYBk8OkYMRbELYy4Nze5gvhaNc93HNb6bkPXAguLXiNvQMchc4AG4awOw2N89wWNtPZcrW25t8ZuedMhmHPDK2KSQC/aA63Yp3UY1FOxzpGudIBhwF07QSIxhyZnYAbrAHTK+ihhxWjDS3G6MsY4lrJczZ8jnEE3ubEW8FmR0jxHezi5pIwPjJjjAj6zmgEY7G3SF8xkdVGyqCWVrzDE94jw84IwXSuFyeifcBGRt65qRhzuF3NJF2i3SbIMJxG7YWAWb3v3i+RVcuK5b0s8ReC76QjLOZxyaOw6b9bm7+5PYbOikaWjEGuDoY4tLOkeQCTpfTO2e5Y8rg578UuIONzKWuGK2lmDee3s0QVPcLB2RDSBia082w4b2aLXMmV7kjMW0zGZS7YngaME08bXYXYOccDNmbkDRjPDPPM7tdUVV3BzWhga0NaLA2sOsBo1x1yAz7c1cLXWADLh5bzmGVkrpXYr2u2+Hut33TBvIuW1SwHHzUpeOjG+LC1g+LE2znXzyue/ctzsna5rLCXZ0WCx+kB6G+1mvaSc+Dlb5P8kJXgOqnODC0YacPkwjIWDhfd4r0nZHJtrcDXMOY+jgYAHOA3n4G9p/ws5z2XjfdydByFZWusyEQjQysxgN7m3s49nyXtew9lx0lNBSxXwQxtY0nV1hm49pNz4qzs3ZYjwufhxNHQYwWZF2N+I/ePgAtmrVifdSZSihSrIEREBERAREQY6IpQFg1WyaeW+OFhvrlb5LORBoX8mIxnDLPBwDHktH8uisv2XXM6s0M44Sx4SfFtgukRByMj5mfXUMn4oHiQd9slbFdTnIyuiPCZjmepyXZKiWnY8dNjXfiaD81HGE8pcw2nLhdjmSDixwKtvicMiCL5DLXuW4n5NUrjiEfNu+KNxYfRWTsCVtjFVyZZhszWzAeJzVeC3JqHBWnBbqSGtb14KeoHFjjGf6XX+awppoh9dT1FP2lhc3zbcKs0lMWa1zVQWLZNhgkH0NRG4/AXAH/AD6K3Js+Qe7fuzVZiYWiYa4sVJYsp8RGoI78lAiUJYZjUiFZoiU4FKNaep2NTynFJBE8/GWNxDucMwtdPyQpiQ6J09MWizeYkwgcThcCL9q6jAnNq2oxxm0OTFW6HmI9oSPaT9IJx03j4BI3Not2HyyXLO5DVUREklO2pDSBzNPMGF7c83PcAfIXPYvXRGp5tTymEY8ro+TNLLMYhSV9O7Cc5Y+dh45OdZ1918l1fJjkVFTOJYDLI45uIyaL5ADcAuvjpxbE4hjRq4/IcStvQbKLx02uij+z0kl7ZCOq37oz420TZk7QwNl7Lufog1xBs+ZwuyM7wwe+70G87j01FRMiBDbkuze92bnni4/oMhuAV6NgaA1oDQBYAAAADcAqlaK4pM6lEUqyBERAUqEQSiIgIiILARQpQERSEEKVKIIspREBEUoIUoiDDq9lU831kMbu0tF/MLXu5MxN+plng4BkhLR/K64W8RBzz9l1jerPDOOE0eEnxbl6LFljmb9bQu/FTvbJ6ZFdWijITsuKNRTXsZHQn4Z2Oj9SAFkNoy4XY5kg4scCurkja4Wc0OHAgH5rXTcnqRxvzLWH4o7xHzbZRxTyaJ1O4atI8FRgW5dsJ7fqauZv3ZMMzfUX9Vb/AHCqHWbTTdoxxHys5RxTyasRq/FT9INwmR5zEY3D4nn3W/7z0W3ioHnItji4lpxu8LtAHqs+mpmRizBa5uTqXHiTqSoipNmJQ7MDSJJSJHjq2HQi7GDj94592i2KIrxGKClEUiUUKUBERAREQSihEEoihBjqoKEQSpCIgkIiICIiCUREBERAREQEUogIiICIiAilEBERARSiAiIgIiICIiAiIgIiIP/Z",
    //                         "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyY9pTKjDGoXzy9Q1SUuS-AE2YPugFSqCMIw&s",
    //                         ]
    //       },
    //     {   ID:2,
    //         name : 'laptap2' ,
    //         about : 'Ram = 2GB  , Hard = 5TB' ,
    //         price : 340,
    //         count : 5,
    //         imageAdderss : ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQk0zNufBvC7jrwj0pDs0ZdG421adXS-BcRHg&s",
    //                         "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQDw8PDw8PDxUQDw8QDxAQEA8PFQ8VFREWFhUSFRUYHSggGBolGxYVIjEhJSotLi4uGB8zODUtNygtLysBCgoKDg0OGhAQGi0lHR0rLS8tLSsrLS0tLS8rKzctLy0tLS0wLS0tKy0uLystLS0tMC0tLS0vKy4tNy0tKy0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAQIDBAUGBwj/xABDEAABAwIDAwkEBwcCBwAAAAABAAIDBBESITEFQVEGEyIyYXGBkaEHQlKxIzNTYnKywQgUc4KSwtFD8BU1Y2TD4fH/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAQIDBAUG/8QAKxEBAAMAAQMCBQIHAAAAAAAAAAECERIDITEEQQVRcYHwYZETFCIjMrHR/9oADAMBAAIRAxEAPwD1oBVIEUgpREBERAUopUApUKbIJClFKAi8P5c+0HaR2jVU9DUR00VI4x5thJlc2weSZAbnFcBo3DvWFH7RdvxXDn0k1m4yTHE8Yb2xXjIFlrHRvaNiB78i8Qh9ru1o7ifZ1O/DbFhE0Nr6Xu51lnU/twcDabZUje2OfF6Fg+aielePNZ/YexBF5fB7cNnkgS01bF24Inj84PotrTe17Yr7XqJY/wAdPN82grPB3ikLmab2g7Ik6u0qUfjfzX5wFt6TblHKAYqulkvpgniffyKDYIoaQdCD3ZqqyAiIgIiICIiAiIgIiICKUQQilEGCpRFIIpRBClFKCFKKQFABVIApQECK3Uy4GPefcY5x/laT+iD5P2xPjra2Uf6lZUv78Urj+qpjkWBASRcm5JJJ4krIjK9j0/akLVlnsncLgOIva9ja9tLrIi2hJm10ji17jjBN73sC7PfkM+xYDSql08p8unpxSe1obmePEbk6C2TWN88IFz26rGdSMOrWnvaFkQyYmNPZY94yUFelEUtHjs4LRMTjBk2bGfcb4XHyWom2VKCbMaRc2sRpu1XREqglc/X9D0Or7Z9MhHKYaGAVUX1Zmj/hvc38pXRUu2NpxfV7UrG9hllcPJziFbBVV1jT4X0K7uz+fphyltIOXW3oz0doCQcJI4XX82X9VtYvant5jWudDSTNJIDjC4BxFrgFrxnmuVuFN+0jxVb/AAvoT42PumLT7u3h9tla0fS7Lif/AA5ZGX9HLZU/t1gt9Ns6pj44JGP/ADBq80knd1cRsG4LEk2bixYRwGLO3FVyV8jnOc8tcXOa512M6RbpuyHEDXesLfCqe1jnL1uk9tuyX9cVcP44Wu/I4rb0ntU2LJkK5rP4kU8fqW2XhD6lmQdBC+wcDdrhiu7FiJDhmNB2DerTjSE50uH8EhBGfEgrC3wy0eLfn7nN9RbK2tTVbDJSzxVDQbF0T2vDTwNtD2FZq+evYrOWbbdHAXNikp5cbC7FcNILcWlyL623nivoZebenC01n2XidQilFRIiIgIiIMOyWVVkspEIqrJZBFksqrIggBSpSygEU2U2QRZablrUGLZm0JBkW0VTbvMTgPUhbqy5D2u1HN7DryNXMijH887Gn0JSB8zw5NHcritNUgr2enOViBlxvV8LBaVkQPzsVtEtK2ZlPKWG+49YLY6i4zvvWrBWTQvs8N3Oy8dy6Ol1OM57L3pz7+6+4KkhZTo1ZcxdmueaLSpLlcLVbAVZsrwS1S59ksrTyo5GKSVQ56kq2VXVZ7KSqSqiqSqyo772BU+LalXL9nTYe7E4D+1e+rxj9nSm/wCZT/E+KPyxO/Ve0L5bqTt5n5y3jwhFKKiUKURARFKDFsilFIIpRBClFKgQpRSgJZSApQRZede3qpwbHwfbVcEfkHSf2L0deSftE1FqWgi+Opkk/oit/wCRTHkeFgqsK2VLXL1Kyqugq4xyshwVQW0SszWSK8yTeNRmsFrlW161iWtbY61hD2tcPeF+7sVp8atbCmxMczh0h3HX1+azZWrvrbY1pNdhr5QrVlkyhWbKsz3ZzXFt+is2V15uqCEZTCy9Wyrj1Q5QylQVbkNgT2KsqxVO6Lu4qnUtlZlR7l+z3S4dmTSfa1Tz4Na1v+V6iuI9jFLzexKT/qc7L/VISPRduvlnQIiICIiAiIgx0RFIIikKARFKApAQKUBSgRAXh37Rc959nR/DDUP/AK3sH9i9xXzv7f58W1423+rooW24EySuPzCtXyPNkUKLrsi+eVVakOVN0uton5IXmScVdBWIr0Lty1pf2lest1sSfDI3tNj45f4XRzBcdTOsV2JkD42PHvNBPfv9brs6d8jHb0f6oxgyrGeVkSlWCFpyL0WrKlyrKocrRLmtC05WnKtxVp5SZYWhQ4rFrXdArIcVi1DC8sYNXva0eJt+q5fVWzpW+ikeX1ZyEpeZ2Xs+Le2lhv3loJ+a3qs0UWCKJg9yNjfJoCvL56WwiIgIiICIiDHRUh4OhCqQFIUKUBSoUPjB1QVhSsN8T29VxKtireNfUINiEWE2u4t8ldbVt7QgyF8xe2aox7crODOYjHhBGT6kr6abM06OC+T/AGg1fO7W2k7/ALydo7mOwD8qtXyNAoKXS625ahCqBVKK1b8RUpabFUgpddEW91Wwhdot/suqIbgOmo/ULloJLHPT5LdUr9CF2dOYtDr9P1MtrbyG6svar7HAi6hwXTj0epWto2GIVaesmQLHkU64b0Y71aeFW9Y8sirMuS/ZRIVkcm6Yy7RoIviq4L9wkBPoCsBzl0/spp+d25QDUMe+Q9zY3H52XF6y39tlXy+pFCIvGaiIiAiIgIiIMQxNO4KnmRuLh3FXrJZBZLXjRwPeP1CB7hq3yKvWSyChso4EevyVQeDoQpLOxQY/9mx+aCsKiWBrtR4hQIraehIU9Ibz4gH5IMKalc3MZhWLrah54X7j+hWFV1UV7EOxb7CxHnqmiy0r5M2vPzlTUSfaTzPz+88n9V9T1dcyMF18gLkuIYB3k6LwmfYTC5zIamCaxIDQ5hPkCT6KOUQnJcIoXVVnJuRusAN75s/xkVqKjZgb1myR/iBHzCty1GNZddXsrkW6poH1jKiMOaYxzDm2vjm5tvTvlfI6b1z7qA7nA94WTS1lXC0sile1pdG8ta/ImN4ewkHLJwv3rSl65O/ZW0TMxk/VtZ+QdaJY4YeZqnSNlc0QPOkeDETzgaf9RluN1qpeT1a3nL0lQRC8xyubE97Y3gA4S5oIBsQdd4W1pOW9dDOyezMTI5GfUtaDzjmue44bC5LG9wGi3NF7TiKKtpZKbG+qNQ8TtktgfKLNcWFp6uRBB90d6fxLReYr/j7arTluX8fo8/8A/qztn1eEhrtDoeH/AKXcUHKyhnqKNtXjdCyfHI2WLnQwNp5GMbZuK4xuZkB7vYto+i2JV104hFIYy2lawY30oBtI6V7Ggsv7gOWWG2V1vHqLdOeWdohpWcnXJQyq6ZFkSbHgbRGpiklcccwa0Fr2hjX9C5AyOFzb3OXAK9S8m5ZNmzbSbKMMMpjMRbm5oLAXh99xfpbcc9y9Svqaz/r7u6nW2sT8/wDuNa9yxnlZVdQyQxxSvdG5srQ5uBxJbfc4ECxyPEZarXSTK8dSLRsIteJhTM+y18j81dnkWI9ypa+OHqzqouXoXsDp8e2HPtlFSSm/AlzGj5leb4l7D+zlTXn2hLbqxQMB/E55PyC8/wBXfaxClIe5oiLz2giIgIiICIiCxdTdUogrupVtSguIqLqHSAC5IAGpOSC4oc4AXJAA1JyWrqtsAZRjEfiOQ8tSuT5QcpXREhzJZCADicyRkQvwfhwk8Rl3qupx1tZtdjQcNjYZvd0Wt7c1xW1+V0bSQwmV2uKzwzP7wGfp3rkK/as9T9YcYbZ1mFzGg7sLQNbHW/HNYRm3F0jbZ2JbIeH3ipzfJvyZG09qyzAmSZj7ZtwvcwNNjbCxt8/G64naVKScbmEgkm5JAfbM5k3J3WHYuokkJcW3DssJY5wYDnc3tuyGRF1ptox5kMY3pAYgwlzm53JZmNLa9tipGogqZo+jHLNFa4MbHPu34iGggAWsbnhqsyHlJVNAxSRvByBkY2xOV7vADnkaEN4jNYUkYDcLgS3Lm+rhiL3HOVwB1Ad0bk65KwGm5c42cQ4MIDi6ou63Rve3YQ0eajDW8btuJ+U1FG99hbm+gXXzF74sPmT2BQJtnPF7VEPFwwvaDfqg3JdqDk1aRgJDhYAR43SMdcNZcgAtF8TiDudfyuojkJOJuI2ucQ67QOrieeixu7o+N8kw1v8A/hNO8XiroshdwlHNlovYYsWHDnbUbxxVM3JWoIxNZHMNQWOBBHG5AHqtHcZdWwcRez+aJaBoOs5x33tuVcZLX2aXh/RFm2ElrAmzh0Y278rkW4XTJOy7UbDkb1qeQdrWucPNtwsB1KBcBxG4g/IhbqDlBVsbdtQXNHQxyXlZG452BcCXuGt8xbdos48qZDZs8FPMMPvRdN+fWIDg1g7xfMHNImYOzmA2Vowh9xe+HMC+Wdt+gW1g5UVzKR9DivTvIc6INj1xh9w62LrNG9bIV+zpBaWkMJF7uhkBbllZtsOI3vpcDig2fs6TDzdXNC5/UjljcTpe9mt07cW5aV614/NT3+bR1e2jI1rXtLcOQyPrn2epWI6rB0K6ZvJR8gJpqmmqACAcDxlfQENLrHXVYNXyXqmHpUxPa3C6/gDf0W1fWWiM7E7jQPlJ3q1dZ8+zizrxyR/ia5n5gsf924O/VT/Mb5Z4sr339nSntQ1ktuvVBgPEMib+rivB/wB2d2HuNl9J+wul5vYsTiLGSaoefCQs/tWXUvFvCYh6AoUqFkkREQEREBERBjqURAUOcALkgAakmyiR4aC5xsBqudq5xI8/TN1OFjjhIG6wUTOJiGxqtrtGUYxH4jkPLUrVzVD3m7nE/IdwVLqd490+GfyVtUmdXiITdLoiqljVOz4JTeSGJ5+JzGlw7nahayo5L0zrlofEXa824EXta+F4cB4BbslUuKnUY5Gr5Ia4Jg4EWwytN+7E02Ge7Cuc2pyVqR0mwslJdd2CU4j3k4Lg9mfavTHBWHtTlJxh4ftPZ1RG674ZYw29sUJMYytlcFp79VrHyg5AXblcF13OsDbp2yAJOQsON9V749i1tbsenm+tp4ZO10bSfO11P8Q4PFC9vQaXdUtIe1lhHbPosyxu3FzuHiqiTbrBjpAMV3AmUONzjdcCJhFsr38Dl6bV8g6F98LJISd8cjjbwfcLSVfs3+xqfCWP+5p/RWi8K8ZcbALB8jA29nMIzwsOgbG4kl787ix8wpgYBk8OkYMRbELYy4Nze5gvhaNc93HNb6bkPXAguLXiNvQMchc4AG4awOw2N89wWNtPZcrW25t8ZuedMhmHPDK2KSQC/aA63Yp3UY1FOxzpGudIBhwF07QSIxhyZnYAbrAHTK+ihhxWjDS3G6MsY4lrJczZ8jnEE3ubEW8FmR0jxHezi5pIwPjJjjAj6zmgEY7G3SF8xkdVGyqCWVrzDE94jw84IwXSuFyeifcBGRt65qRhzuF3NJF2i3SbIMJxG7YWAWb3v3i+RVcuK5b0s8ReC76QjLOZxyaOw6b9bm7+5PYbOikaWjEGuDoY4tLOkeQCTpfTO2e5Y8rg578UuIONzKWuGK2lmDee3s0QVPcLB2RDSBia082w4b2aLXMmV7kjMW0zGZS7YngaME08bXYXYOccDNmbkDRjPDPPM7tdUVV3BzWhga0NaLA2sOsBo1x1yAz7c1cLXWADLh5bzmGVkrpXYr2u2+Hut33TBvIuW1SwHHzUpeOjG+LC1g+LE2znXzyue/ctzsna5rLCXZ0WCx+kB6G+1mvaSc+Dlb5P8kJXgOqnODC0YacPkwjIWDhfd4r0nZHJtrcDXMOY+jgYAHOA3n4G9p/ws5z2XjfdydByFZWusyEQjQysxgN7m3s49nyXtew9lx0lNBSxXwQxtY0nV1hm49pNz4qzs3ZYjwufhxNHQYwWZF2N+I/ePgAtmrVifdSZSihSrIEREBERAREQY6IpQFg1WyaeW+OFhvrlb5LORBoX8mIxnDLPBwDHktH8uisv2XXM6s0M44Sx4SfFtgukRByMj5mfXUMn4oHiQd9slbFdTnIyuiPCZjmepyXZKiWnY8dNjXfiaD81HGE8pcw2nLhdjmSDixwKtvicMiCL5DLXuW4n5NUrjiEfNu+KNxYfRWTsCVtjFVyZZhszWzAeJzVeC3JqHBWnBbqSGtb14KeoHFjjGf6XX+awppoh9dT1FP2lhc3zbcKs0lMWa1zVQWLZNhgkH0NRG4/AXAH/AD6K3Js+Qe7fuzVZiYWiYa4sVJYsp8RGoI78lAiUJYZjUiFZoiU4FKNaep2NTynFJBE8/GWNxDucMwtdPyQpiQ6J09MWizeYkwgcThcCL9q6jAnNq2oxxm0OTFW6HmI9oSPaT9IJx03j4BI3Not2HyyXLO5DVUREklO2pDSBzNPMGF7c83PcAfIXPYvXRGp5tTymEY8ro+TNLLMYhSV9O7Cc5Y+dh45OdZ1918l1fJjkVFTOJYDLI45uIyaL5ADcAuvjpxbE4hjRq4/IcStvQbKLx02uij+z0kl7ZCOq37oz420TZk7QwNl7Lufog1xBs+ZwuyM7wwe+70G87j01FRMiBDbkuze92bnni4/oMhuAV6NgaA1oDQBYAAAADcAqlaK4pM6lEUqyBERAUqEQSiIgIiILARQpQERSEEKVKIIspREBEUoIUoiDDq9lU831kMbu0tF/MLXu5MxN+plng4BkhLR/K64W8RBzz9l1jerPDOOE0eEnxbl6LFljmb9bQu/FTvbJ6ZFdWijITsuKNRTXsZHQn4Z2Oj9SAFkNoy4XY5kg4scCurkja4Wc0OHAgH5rXTcnqRxvzLWH4o7xHzbZRxTyaJ1O4atI8FRgW5dsJ7fqauZv3ZMMzfUX9Vb/AHCqHWbTTdoxxHys5RxTyasRq/FT9INwmR5zEY3D4nn3W/7z0W3ioHnItji4lpxu8LtAHqs+mpmRizBa5uTqXHiTqSoipNmJQ7MDSJJSJHjq2HQi7GDj94592i2KIrxGKClEUiUUKUBERAREQSihEEoihBjqoKEQSpCIgkIiICIiCUREBERAREQEUogIiICIiAilEBERARSiAiIgIiICIiAiIgIiIP/Z",
    //                         "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyY9pTKjDGoXzy9Q1SUuS-AE2YPugFSqCMIw&s",
    //                         ]
    //       },
    //     ]
    // },

     
    }
    render(){

        return(
            <>
                <Navbar buyBasketE={this.buyBasketE} isBuyBasket={this.state.isBuyBasket} homeE={this.homeE}
                serchE = {this.serchE} goToProfile = {this.goToProfile} />

                {this.makepak()}

                {/* <Home/> */}
                {/* <Prodacts addProdactTOBuybasket = {this.addProdactTOBuybasket} buyBasketdeleltE={this.buyBasketdeleltE}/> */}
               
               
                
            </>
        )
    }
    
    makepak = ()=>{
        return(this.state.pak)
    }
    
}

export default app