import axios from "axios"

// const api = class api {
//     token = '';
//     con ;
//     constructor(){
//         this.con = axios.create({
//         baseURL:"http://project000014.liara.run/api",
//         headers :{'Content-Type':'application/json'
//         ,'x-auth-token' : this.token
//     }
//     })
//     }
//     get = (url , promms = {})=>{
//         return this.con.get('/user').then((res)=>{
//             console.log(res)
//         })
//     }
//     post = (url , data)=>{
//         return this.post(url,data);
//     }
// }
const con = axios.create({
    baseURL:"http://project000014.liara.run/api",
    headers :{'Content-Type':'application/json'
    // ,'x-auth-token' : this.token
}
})
var api = ()=>{
            axios.post('https://project000014.liara.run/api/auth/register', {
                email : "ali23@gmail.com",
                name : "ali23",
                password : "123",
                usertype : "seller"
            }).then((res)=>{
                    console.log(res.data)
                }).catch((err)=>{
                    console.error(err)
        })}
// const api2 =()=>{

// a.get('http://project000014.liara.run/api/user').then((res)=>{
//     console.log(res.data)
// }).catch((err)=>{
//     console.error(err)
// })

// }


export default api